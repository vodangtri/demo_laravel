 
<?php $__env->startSection('content'); ?> 
<div class="card">
    <div class="card-header">Chỉnh sửa thông tin</div>
    <div class="card-body">
      <form action="<?php echo e(url('courses/'.$courses->id)); ?>" method="post"> 
        <?php echo csrf_field(); ?>

         <?php echo method_field("PATCH"); ?> 
         <input type="hidden" name="id" id="id" value="<?php echo e($courses->id); ?>" id="id" />
        <label>Tên</label></br>
        <input type="text" name="name" id="name" value="<?php echo e($courses->name); ?>" class="form-control"></br>
          <label>Giáo trình</label></br>
          <input type="text" name="syllabus" id="syllabus" value="<?php echo e($courses->syllabus); ?>" class="form-control"></br>
          <label>Thời lượng</label></br>
          <input type="text" name="duration" id="duration" value="<?php echo e($courses->duration); ?>" class="form-control"></br>
          <input type="submit" value="Cập nhật" class="btn btn-success"></br>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TRI\StudentManagement_Laravel\resources\views/courses/edit.blade.php ENDPATH**/ ?>