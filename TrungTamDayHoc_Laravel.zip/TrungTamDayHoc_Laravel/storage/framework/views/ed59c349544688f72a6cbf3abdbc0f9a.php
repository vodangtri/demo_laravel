 
<?php $__env->startSection('content'); ?> 

<div class="card">
    <div class="card-header">Tạo mới học viên</div>
    <div class="card-body">
      <form action="<?php echo e(url('students')); ?>" method="post"> 
        <?php echo csrf_field(); ?>

         <label>Tên</label>
        </br>
        <input type="text" name="name" id="name" class="form-control">
        </br>
        <label>Địa chỉ</label>
        </br>
        <input type="text" name="address" id="address" class="form-control">
        </br>
        <label>Số điện thoại</label>
        </br>
        <input type="text" name="mobile" id="mobile" class="form-control">
        </br>
        <input type="submit" value="Lưu" class="btn btn-success">
        </br>
      </form>
    </div>
  </div> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TRI\TrungTamDayHoc_Laravel\resources\views/students/create.blade.php ENDPATH**/ ?>