 
<?php $__env->startSection('content'); ?> 

<div class="card">
    <div class="card-header">Thêm mới khóa học</div>
    <div class="card-body">
      <form action="<?php echo e(url('courses')); ?>" method="post"> 
        <?php echo csrf_field(); ?>

         <label>Tên</label>
        </br>
        <input type="text" name="name" id="name" class="form-control">
        </br>
        <label>Giáo trình</label>
        </br>
        <input type="text" name="syllabus" id="syllabus" class="form-control">
        </br>
        <label>Thời lượng</label>
        </br>
        <input type="text" name="duration" id="duration" class="form-control">
        </br>
        <input type="submit" value="Lưu" class="btn btn-success">
        </br>
      </form>
    </div>
  </div> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TRI\StudentManagement_Laravel\resources\views/courses/create.blade.php ENDPATH**/ ?>