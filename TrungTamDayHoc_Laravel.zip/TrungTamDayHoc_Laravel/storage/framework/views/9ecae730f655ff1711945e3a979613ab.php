<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css" integrity="sha384-xOolHFLEh07PJGoPkLv1IbcEPTNtaed2xpHsD9ESMhqIYd0nLMwNLD69Npy4HI+N" crossorigin="anonymous">
 <title>Document</title>

 <style>
  .nav-item {
    margin-left: 20px;
    margin-right: 20px;
}
/* The side navigation menu */
.sidebar {
  margin: 0;
  padding: 0;
  width: 200px;
  background-color: #f1f1f1;
  position: fixed;
  height: 100%;
  overflow: auto;
}

/* Sidebar links */
.sidebar a {
  display: block;
  color: black;
  padding: 16px;
  text-decoration: none;
}

/* Active/current link */
.sidebar a.active {
  background-color: #04AA6D;
  color: white;
}

/* Links on mouse-over */
.sidebar a:hover:not(.active) {
  background-color: #555;
  color: white;
}

/* Page content. The value of the margin-left property should match the value of the sidebar's width property */
div.content {
  margin-left: 200px;
  padding: 1px 16px;
  height: 1000px;
}

/* On screens that are less than 700px wide, make the sidebar into a topbar */
@media screen and (max-width: 700px) {
  .sidebar {
    width: 100%;
    height: auto;
    position: relative;
  }
  .sidebar a {float: left;}
  div.content {margin-left: 0;}
}

/* On screens that are less than 400px, display the bar vertically, instead of horizontally */
@media screen and (max-width: 400px) {
  .sidebar a {
    text-align: center;
    float: none;
  }
}
 </style>
  </head>
  <body>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <nav class="navbar navbar-expand-sm bg-light navbar-light">
                    <a class="navbar-brand" href="#"><h2 style="font-weight:bolder;font-style: italic">Trung tâm dạy học</h2></a>
                    <ul class="navbar-nav">
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/home')); ?>">Trang chủ</a>

                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/students')); ?>">Học viên</a>

                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/teachers')); ?>">Giáo viên</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/courses')); ?>">Khóa học</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/batches')); ?>">Nhóm học</a>
                      </li>
                      <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('/enrollments')); ?>">Đăng kí</a>
                      </li>
                    </ul>
                  </nav>
            </div>
            <div class="col-md-12 mt-4">
              <?php echo $__env->yieldContent('content'); ?></div>
          </div>
        </div>
        <!--<div class="row">
            
            <div class="col-md-3">
                <div class="sidebar">
                  <a class="active" href="#home">Home</a>
                  <a href="<?php echo e(url('/students')); ?>">Student</a>
                  <a href="<?php echo e(url('/teachers')); ?>">Teacher</a>
                  <a href="<?php echo e(url('/courses')); ?>">Course</a>
                  <a href="<?php echo e(url('/batches')); ?>">Batch</a>
                  <a href="<?php echo e(url('/enrollments')); ?>">Enrollment</a>
                  <a href="#about">Payment</a>
                </div>    
            </div>

            <div class="col-md-9">
                <?php echo $__env->yieldContent('content'); ?></div>
            </div>
        </div>-->
    </div>

  </body>
</html>
<?php /**PATH C:\Users\TRI\TrungTamDayHoc_Laravel\resources\views/layout.blade.php ENDPATH**/ ?>