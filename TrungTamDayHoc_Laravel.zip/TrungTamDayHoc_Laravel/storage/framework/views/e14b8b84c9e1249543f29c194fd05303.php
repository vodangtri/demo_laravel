 
<?php $__env->startSection('content'); ?> 

<div class="card">
    <div class="card-header">Thêm mới nhóm học</div>
    <div class="card-body">
      <form action="<?php echo e(url('batches')); ?>" method="post"> 
        <?php echo csrf_field(); ?>

         <label>Tên nhóm</label></br>
        <input type="text" name="name" id="name" class="form-control"></br>
        <label>Tên khóa học</label></br>
        <select name="course id" id="course id" class="form-control">
          <?php $__currentLoopData = $courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </br>

        <label>Ngày bắt đầu</label></br>
        <input type="text" name="start_date" id="start_date" class="form-control">
        </br>
        <input type="submit" value="Lưu" class="btn btn-success">
        </br>
      </form>
    </div>
  </div> <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TRI\TrungTamDayHoc_Laravel\resources\views/batches/create.blade.php ENDPATH**/ ?>