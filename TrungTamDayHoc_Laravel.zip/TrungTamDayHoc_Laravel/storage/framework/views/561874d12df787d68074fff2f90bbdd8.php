 
<?php $__env->startSection('content'); ?> 
<div class="card">
    <div class="card-header">Thông tin khóa học</div>
    <div class="card-body">
      <div class="card-body">
        <h5 class="card-title">Tên: <?php echo e($courses->name); ?></h5>
        <p class="card-text">Giáo trình: <?php echo e($courses->syllabus); ?></p>
        <p class="card-text">Thời lượng: <?php echo e($courses->duration); ?></p>
      </div>
      </hr>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TRI\StudentManagement_Laravel\resources\views/courses/show.blade.php ENDPATH**/ ?>