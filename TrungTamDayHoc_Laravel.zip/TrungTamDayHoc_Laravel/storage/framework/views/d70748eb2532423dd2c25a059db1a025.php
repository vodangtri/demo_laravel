 
<?php $__env->startSection('content'); ?> 
<div class="card">
    <div class="card-header">Chỉnh sửa thông tin đăng kí</div>
    <div class="card-body">
      <form action="<?php echo e(url('enrollments/'.$enrollments->id)); ?>" method="post">
        <?php echo csrf_field(); ?>

        <?php echo method_field("PATCH"); ?>
        <input type="hidden" name="id" id="id" value="(($enrollments->id))" id="id" />
        
        <label>Mã</label></br>
        <input type="text" name="enroll_no" id="enroll_no" class="form-control" value="<?php echo e($enrollments->enroll_no); ?>"></br>
        
        <label>Tên nhóm học</label></br>
        <input type="text" name="batch_id" id="batch_id" class="form-control" value="<?php echo e($enrollments->batch->name); ?>"></br>
        
        <label>Tên học sinh</label></br>
        <input type="text" name="student_id" id="student_id" class="form-control" value="<?php echo e($enrollments->student->name); ?>"></br>
        
        <label>Ngày đăng kí</label></br>
        <input type="text" name="join_date" id="join_date" class="form-control" value="<?php echo e($enrollments->join_date); ?>"></br>
        
        <label>Học phí</label></br>
        <input type="text" name="fee" id="fee" class="form-control" value="<?php echo e($enrollments->fee); ?>"></br>
        <input type="submit" value="Cập nhật" class="btn btn-success"></br>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TRI\StudentManagement_Laravel\resources\views/enrollments/edit.blade.php ENDPATH**/ ?>