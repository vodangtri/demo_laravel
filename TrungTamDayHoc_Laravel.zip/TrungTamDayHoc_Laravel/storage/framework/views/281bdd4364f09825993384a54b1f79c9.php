 
<?php $__env->startSection('content'); ?> 
<div class="card">
    <div class="card-header">Chỉnh sửa thông tin</div>
    <div class="card-body">
      <form action="<?php echo e(url('teachers/'.$teachers->id)); ?>" method="post"> 
        <?php echo csrf_field(); ?>

         <?php echo method_field("PATCH"); ?> 
         <input type="hidden" name="id" id="id" value="<?php echo e($teachers->id); ?>" id="id" />
        <label>Tên</label></br>
        <input type="text" name="name" id="name" value="<?php echo e($teachers->name); ?>" class="form-control"></br>
          <label>Địa chỉ</label></br>
          <input type="text" name="address" id="address" value="<?php echo e($teachers->address); ?>" class="form-control"></br>
          <label>Số điện thoại</label></br>
          <input type="text" name="mobile" id="mobile" value="<?php echo e($teachers->mobile); ?>" class="form-control"></br>
          <input type="submit" value="Cập nhật" class="btn btn-success"></br>
      </form>
    </div>
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TRI\TrungTamDayHoc_Laravel\resources\views/teachers/edit.blade.php ENDPATH**/ ?>