 
<?php $__env->startSection('content'); ?> 

<div class="card">
    <div class="card-header">Đăng kí học viên mới</div>
    <div class="card-body">
        <form action="<?php echo e(url('enrollments')); ?>" method="post">
          <?php echo csrf_field(); ?>

          <label>Mã đăng kí</label></br>
          <input type="text" name="enroll_no" id="enroll_no" class="form-control"></br> 
          <label>Tên nhóm học</label></br>
          <select name="batch_id" id="batch_id" class="form-control">
            <?php $__currentLoopData = $batches; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          </br>
          <label>Tên học viên</label></br>
          <select name="student_id" id="student id" class="form-control">
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($id); ?>"><?php echo e($name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </br>
          <label>Ngày đăng kí</label></br>
          <input type="text" name="join_date" id="join_date" class="form-control"></br>
          <label>Học phí</label></br>
          <input type="text" name="fee" id="fee" class="form-control"></br>
        <input type="submit" value="Lưu" class="btn btn-success">
      </form>
    </div>
</div> 
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TRI\TrungTamDayHoc_Laravel\resources\views/enrollments/create.blade.php ENDPATH**/ ?>