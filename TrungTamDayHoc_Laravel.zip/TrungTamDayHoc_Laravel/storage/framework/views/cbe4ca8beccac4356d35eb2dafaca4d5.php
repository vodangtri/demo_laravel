 
<?php $__env->startSection('content'); ?> 
    <div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
        <h1 style="font-weight:bolder;font-family: Arial, sans-serif; font-style: italic;">Chào mừng đến với trung tâm dạy học</h1>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TRI\TrungTamDayHoc_Laravel\resources\views/home/index.blade.php ENDPATH**/ ?>