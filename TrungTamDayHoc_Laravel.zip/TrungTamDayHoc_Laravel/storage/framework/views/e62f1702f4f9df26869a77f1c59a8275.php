 
<?php $__env->startSection('content'); ?> 
<div class="card">
    <div class="card-header">Thông tin giáo viên</div>
    <div class="card-body">
      <div class="card-body">
        <h5 class="card-title">Tên: <?php echo e($teachers->name); ?></h5>
        <p class="card-text">Địa chỉ: <?php echo e($teachers->address); ?></p>
        <p class="card-text">Số điện thoại: <?php echo e($teachers->mobile); ?></p>
      </div>
      </hr>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\TRI\StudentManagement_Laravel\resources\views/teachers/show.blade.php ENDPATH**/ ?>