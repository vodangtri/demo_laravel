@extends('layout') 
@section('content') 
<div class="card">
    <div class="card-header">Thông tin học viên</div>
    <div class="card-body">
      <div class="card-body">
        <h5 class="card-title">Tên: {{ $students->name }}</h5>
        <p class="card-text">Địa chỉ: {{ $students->address }}</p>
        <p class="card-text">Số điện thoại: {{ $students->mobile }}</p>
      </div>
      </hr>
    </div>
</div>
@endsection