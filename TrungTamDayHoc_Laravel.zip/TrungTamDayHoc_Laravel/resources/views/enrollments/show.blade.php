@extends('layout') 
@section('content') 
<div class="card">
    <div class="card-header">Thông tin đăng kí</div>
    <div class="card-body">
      <h5 class="card-title">Mã: {{ $enrollments->enroll_no }}</h5>
      <p class="card-text">Tên nhóm: {{ $enrollments->batch->name }}</p>
      <p class="card-text">Tên học sinh: {{ $enrollments->student->name }}</p>
      <p class="card-text">Ngày đăng kí: {{ $enrollments->join_date }}</p>
      <p class="card-text">Học phí: {{ $enrollments->fee }}</p>
    </div>
      </hr>
    </div>
</div>
@endsection