@extends('layout') 
@section('content') 
    <div style="display: flex; justify-content: center; align-items: center; height: 100vh;">
        <h1 style="font-weight:bolder;font-family: Arial, sans-serif; font-style: italic;">Chào mừng đến với trung tâm dạy học</h1>
    </div>
@endsection

