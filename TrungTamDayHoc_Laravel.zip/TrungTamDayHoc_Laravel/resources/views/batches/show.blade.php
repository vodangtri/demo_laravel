@extends('layout') 
@section('content') 
<div class="card">
    <div class="card-header">Thông tin nhóm</div>
    <div class="card-body">
      <div class="card-body">
        <h5 class="card-title">Tên nhóm: {{ $batches->name }}</h5>
        <p class="card-text">Mã khóa học: {{ $batches->course->name }}</p>
        <p class="card-text">Ngày bắt đầu: {{ $batches->start_date }}</p>
      </div>
      </hr>
    </div>
</div>
@endsection